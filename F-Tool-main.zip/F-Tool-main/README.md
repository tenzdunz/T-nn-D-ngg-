# F-Tool
git clone https://github.com/tenndungg/F-Tool.git                                  cd F-Tool; sh install.sh 
