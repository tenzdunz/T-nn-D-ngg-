# F-Tool
git clone https://github.com/FDc0d3/F-Tool.git                                  cd F-Tool; sh install.sh 
